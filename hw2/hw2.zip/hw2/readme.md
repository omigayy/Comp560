##Readme

Put your game board files in the same directory with the source code. Then you will be prompted to type in the file name. The program will automatically run and return the result.

